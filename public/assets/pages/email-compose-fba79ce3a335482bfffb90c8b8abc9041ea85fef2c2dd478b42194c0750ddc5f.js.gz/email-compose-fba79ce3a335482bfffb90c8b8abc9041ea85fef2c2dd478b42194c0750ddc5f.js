(function () {
  $.turbo.execute(".email-compose-page", function() {
    $("#compose-textarea").summernote({
      height: 300
    });
  })
})()
;
