(function() {
  $.turbo.execute(".slider-page", function() {
    console.log("init slider")
    $('.slider').slider()
  })
})()
;
